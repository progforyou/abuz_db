const rootIds = [494127139, 473018697, 854199194]
const maxSize = 4096


module.exports = {
    rootIds,
    maxSize,
}