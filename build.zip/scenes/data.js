const rootIds = [494127139, 854199194, 5105459903]
const maxSize = 4096


module.exports = {
    rootIds,
    maxSize,
}